LUST RENTALS TAX REPORTING - ACCOUNTANT PACKAGE 2025
============================================================
Generated: 2025-11-09 16:31:37

CONTENTS:

  Income Transactions: income_transactions_2025.csv (37 records)
  Expense Transactions: expense_transactions_2025.csv (54 records)
  Expenses - 966 Kinsbury Court: expenses_966_Kinsbury_Court_2025.csv (1 records)
  Property Summary: property_summary_2025.csv (5 records)
  Database Backup: processed_database_2025.db (0.04 MB)
  Report: property_report_2025.pdf (4461 records)
  Report: schedule_e_2025.csv (1106 records)
  Report: schedule_e_property_summary_2025.csv (254 records)
  Report: expense_breakdown_2025.png (34726 records)
  Report: property_report_2025.xlsx (6622 records)
  Report: lust_rentals_tax_summary_2025.pdf (2000 records)

FILE DESCRIPTIONS:

income_transactions_*.csv:
  - All rental income transactions for the year
  - Grouped by property
  - Includes dates, amounts, and property assignments

expense_transactions_*.csv:
  - All expense transactions for the year
  - Includes categories (repairs, maintenance, utilities, etc.)
  - Property assignments included

expenses_*_*.csv:
  - Expenses broken down by individual property
  - One file per property for easy review

property_summary_*.csv:
  - High-level summary showing income, expenses, and net for each property
  - Use for quick overview of property performance

processed_database_*.db:
  - Complete SQLite database backup
  - Can be opened with SQLite tools for custom queries

NOTES:
- All amounts are in USD
- Dates are in YYYY-MM-DD format
- Categories match IRS Schedule E line items
- 'Lust Rentals LLC' entries are business-level expenses (Schedule C)

For questions about this data, please contact Randy Lust.